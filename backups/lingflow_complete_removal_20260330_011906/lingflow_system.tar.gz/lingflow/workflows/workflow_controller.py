"""
LingFlow 工作流控制器
管理和分析工作流的执行
"""
import logging
import time
from typing import Dict, Any, List
from pathlib import Path
import json
import sqlite3


class WorkflowController:
    """工作流控制器"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化工作流控制器
        
        Args:
            config: LingFlow 配置字典
        """
        self.config = config
        self.logger = logging.getLogger("lingflow.workflows")
        
        # 项目路径
        self.project_path = Path(config['project']['path'])
        
        # 数据库路径
        self.db_path = Path(config['database']['path'])
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 初始化数据库
        self._init_database()
    
    def _init_database(self):
        """初始化数据库"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # 创建工作流表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS workflows (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                status TEXT NOT NULL,
                start_time REAL,
                end_time REAL,
                agents TEXT,
                results TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # 创建 Agent 执行表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_executions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workflow_id INTEGER,
                agent_name TEXT NOT NULL,
                status TEXT NOT NULL,
                start_time REAL,
                end_time REAL,
                execution_time REAL,
                results TEXT,
                FOREIGN KEY (workflow_id) REFERENCES workflows (id)
            )
        """)
        
        conn.commit()
        conn.close()
        
        self.logger.info("数据库初始化完成")
    
    def execute_workflow(
        self,
        name: str,
        agents: List,
        workflow_type: str = "interactive"
    ) -> Dict[str, Any]:
        """
        执行工作流
        
        Args:
            name: 工作流名称
            agents: Agent 列表
            workflow_type: 工作流类型 (interactive/automated/scheduled)
            
        Returns:
            Dict[str, Any]: 工作流执行结果
        """
        self.logger.info(f"开始执行工作流: {name} (类型: {workflow_type})")
        
        start_time = time.time()
        workflow_id = None
        
        try:
            # 记录工作流开始
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO workflows (name, type, status, start_time, agents)
                VALUES (?, ?, ?, ?, ?)
            """, (name, workflow_type, "running", start_time, json.dumps([a.name for a in agents])))
            
            workflow_id = cursor.lastrowid
            conn.commit()
            
            # 按优先级排序 Agents
            sorted_agents = sorted(agents, key=lambda a: a.get_priority())
            
            # 执行 Agents
            all_results = []
            for agent in sorted_agents:
                self.logger.info(f"执行 Agent: {agent.name}")
                
                agent_start_time = time.time()
                
                try:
                    # 执行 Agent
                    result = agent.execute(str(self.project_path))
                    
                    agent_end_time = time.time()
                    execution_time = agent_end_time - agent_start_time
                    
                    # 记录 Agent 执行
                    cursor.execute("""
                        INSERT INTO agent_executions (
                            workflow_id, agent_name, status, start_time,
                            end_time, execution_time, results
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        workflow_id,
                        agent.name,
                        result['status'],
                        agent_start_time,
                        agent_end_time,
                        execution_time,
                        json.dumps(result)
                    ))
                    
                    conn.commit()
                    
                    all_results.append(result)
                    
                except Exception as e:
                    self.logger.error(f"Agent 执行失败 {agent.name}: {e}")
                    
                    # 记录 Agent 执行失败
                    cursor.execute("""
                        INSERT INTO agent_executions (
                            workflow_id, agent_name, status, start_time,
                            end_time, execution_time, results
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        workflow_id,
                        agent.name,
                        "failed",
                        agent_start_time,
                        time.time(),
                        time.time() - agent_start_time,
                        json.dumps({"error": str(e)})
                    ))
                    
                    conn.commit()
                    
                    all_results.append({
                        "agent": agent.name,
                        "status": "failed",
                        "error": str(e)
                    })
            
            # 记录工作流结束
            end_time = time.time()
            execution_time = end_time - start_time
            
            cursor.execute("""
                UPDATE workflows
                SET status = ?, end_time = ?, results = ?
                WHERE id = ?
            """, ("completed", end_time, json.dumps(all_results), workflow_id))
            
            conn.commit()
            conn.close()
            
            self.logger.info(f"工作流执行完成: {name} ({execution_time:.2f}s)")
            
            return {
                "workflow_id": workflow_id,
                "name": name,
                "type": workflow_type,
                "status": "completed",
                "start_time": start_time,
                "end_time": end_time,
                "execution_time": execution_time,
                "agents": [a.name for a in agents],
                "results": all_results
            }
            
        except Exception as e:
            self.logger.error(f"工作流执行失败 {name}: {e}")
            
            # 记录工作流失败
            if workflow_id is not None:
                try:
                    cursor.execute("""
                        UPDATE workflows
                        SET status = ?, end_time = ?, results = ?
                        WHERE id = ?
                    """, ("failed", time.time(), json.dumps({"error": str(e)}), workflow_id))
                    conn.commit()
                except:
                    pass
            
            conn.close()
            
            return {
                "workflow_id": workflow_id,
                "name": name,
                "type": workflow_type,
                "status": "failed",
                "error": str(e)
            }
    
    def get_workflow_status(self, workflow_id: int) -> Dict[str, Any]:
        """
        获取工作流状态
        
        Args:
            workflow_id: 工作流 ID
            
        Returns:
            Dict[str, Any]: 工作流状态
        """
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, name, type, status, start_time, end_time, agents, results
            FROM workflows
            WHERE id = ?
        """, (workflow_id,))
        
        row = cursor.fetchone()
        
        if row:
            conn.close()
            return {
                "id": row[0],
                "name": row[1],
                "type": row[2],
                "status": row[3],
                "start_time": row[4],
                "end_time": row[5],
                "agents": json.loads(row[6]),
                "results": json.loads(row[7])
            }
        else:
            conn.close()
            return None
