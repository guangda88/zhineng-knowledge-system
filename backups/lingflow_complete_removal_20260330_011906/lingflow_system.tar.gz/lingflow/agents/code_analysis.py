"""
代码分析 Agent
检查代码质量、风格、最佳实践等
"""
import logging
import subprocess
import ast
from typing import Dict, Any, List
from pathlib import Path
from .base_agent import BaseAgent


class CodeAnalysisAgent(BaseAgent):
    """代码分析 Agent"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.tools = config.get('tools', [])
        self.rules = config.get('rules', [])
        self.logger = logging.getLogger(f"lingflow.agents.{self.name}")
    
    def analyze(self, target: str) -> List[Dict[str, Any]]:
        """
        执行代码分析
        
        Args:
            target: 分析目标路径
            
        Returns:
            List[Dict[str, Any]]: 分析结果列表
        """
        results = []
        target_path = Path(target)
        
        if not target_path.exists():
            return [{
                "type": "error",
                "message": f"目标路径不存在: {target}"
            }]
        
        self.logger.info(f"开始代码分析: {target}")
        
        # 1. 检查文件数量
        python_files = list(target_path.rglob("*.py"))
        shell_files = list(target_path.rglob("*.sh"))
        
        results.append({
            "type": "summary",
            "metric": "python_files",
            "value": len(python_files),
            "message": f"找到 {len(python_files)} 个 Python 文件"
        })
        
        results.append({
            "type": "summary",
            "metric": "shell_files",
            "value": len(shell_files),
            "message": f"找到 {len(shell_files)} 个 Shell 脚本"
        })
        
        # 2. 分析 Python 文件
        for py_file in python_files[:10]:  # 限制分析文件数量
            try:
                file_results = self._analyze_python_file(py_file)
                results.extend(file_results)
            except Exception as e:
                self.logger.warning(f"分析文件失败 {py_file}: {e}")
                results.append({
                    "type": "error",
                    "file": str(py_file),
                    "message": f"分析失败: {str(e)}"
                })
        
        # 3. 分析 Shell 脚本
        for sh_file in shell_files[:10]:  # 限制分析文件数量
            try:
                file_results = self._analyze_shell_file(sh_file)
                results.extend(file_results)
            except Exception as e:
                self.logger.warning(f"分析文件失败 {sh_file}: {e}")
                results.append({
                    "type": "error",
                    "file": str(sh_file),
                    "message": f"分析失败: {str(e)}"
                })
        
        self.logger.info(f"代码分析完成: {len(results)} 条结果")
        return results
    
    def _analyze_python_file(self, file_path: Path) -> List[Dict[str, Any]]:
        """分析 Python 文件"""
        results = []
        
        try:
            # 读取文件内容
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 检查文件大小
            file_size = file_path.stat().st_size
            if file_size > 100000:  # 100KB
                results.append({
                    "type": "warning",
                    "file": str(file_path),
                    "metric": "file_size",
                    "value": file_size,
                    "message": f"文件过大: {file_size} 字节"
                })
            
            # 检查代码行数
            lines = content.split('\n')
            if len(lines) > 500:
                results.append({
                    "type": "warning",
                    "file": str(file_path),
                    "metric": "line_count",
                    "value": len(lines),
                    "message": f"文件过长: {len(lines)} 行"
                })
            
            # 解析 AST
            try:
                tree = ast.parse(content)
                
                # 检查导入
                imports = [node for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom))]
                if len(imports) > 20:
                    results.append({
                        "type": "warning",
                        "file": str(file_path),
                        "metric": "imports",
                        "value": len(imports),
                        "message": f"导入过多: {len(imports)} 个"
                    })
                
                # 检查函数数量
                functions = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
                if len(functions) > 20:
                    results.append({
                        "type": "warning",
                        "file": str(file_path),
                        "metric": "functions",
                        "value": len(functions),
                        "message": f"函数过多: {len(functions)} 个"
                    })
                
                # 检查类数量
                classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
                if len(classes) > 5:
                    results.append({
                        "type": "warning",
                        "file": str(file_path),
                        "metric": "classes",
                        "value": len(classes),
                        "message": f"类过多: {len(classes)} 个"
                    })
                
            except SyntaxError as e:
                results.append({
                    "type": "error",
                    "file": str(file_path),
                    "message": f"语法错误: {str(e)}"
                })
            
            # 检查文档字符串
            docstring_count = sum(1 for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and ast.get_docstring(node))
            if docstring_count == 0:
                results.append({
                    "type": "warning",
                    "file": str(file_path),
                    "metric": "docstrings",
                    "value": 0,
                    "message": "缺少文档字符串"
                })
            
        except Exception as e:
            results.append({
                "type": "error",
                "file": str(file_path),
                "message": f"读取文件失败: {str(e)}"
            })
        
        return results
    
    def _analyze_shell_file(self, file_path: Path) -> List[Dict[str, Any]]:
        """分析 Shell 脚本"""
        results = []
        
        try:
            # 读取文件内容
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 检查是否设置了错误处理
            if 'set -e' not in content:
                results.append({
                    "type": "warning",
                    "file": str(file_path),
                    "metric": "error_handling",
                    "message": "未设置错误处理 (set -e)"
                })
            
            # 检查是否有 shebang
            lines = content.split('\n')
            if lines and not lines[0].startswith('#!'):
                results.append({
                    "type": "warning",
                    "file": str(file_path),
                    "metric": "shebang",
                    "message": "缺少 shebang"
                })
            
            # 检查硬编码路径
            hardcoded_paths = ['/usr', '/opt', '/home']
            for path in hardcoded_paths:
                if path in content:
                    results.append({
                        "type": "warning",
                        "file": str(file_path),
                        "metric": "hardcoded_path",
                        "message": f"可能包含硬编码路径: {path}"
                    })
            
        except Exception as e:
            results.append({
                "type": "error",
                "file": str(file_path),
                "message": f"读取文件失败: {str(e)}"
            })
        
        return results
