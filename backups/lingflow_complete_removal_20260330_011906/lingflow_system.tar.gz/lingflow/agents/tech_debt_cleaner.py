"""
技术债务清理 Agent
自动清理代码中的技术债务
"""
import logging
import subprocess
import re
from typing import Dict, Any, List
from pathlib import Path
from .base_agent import BaseAgent


class TechDebtCleanerAgent(BaseAgent):
    """技术债务清理 Agent"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.auto_fix = config.get('auto_fix', False)
        self.logger = logging.getLogger(f"lingflow.agents.{self.name}")
    
    def analyze(self, target: str) -> List[Dict[str, Any]]:
        """
        分析技术债务
        
        Args:
            target: 分析目标路径
            
        Returns:
            List[Dict[str, Any]]: 技术债务列表
        """
        results = []
        target_path = Path(target)
        
        self.logger.info(f"开始分析技术债务: {target}")
        
        # 1. 检查 Python 文件中的技术债务
        python_files = list(target_path.rglob("*.py"))
        for py_file in python_files:
            file_results = self._analyze_python_debt(py_file)
            results.extend(file_results)
        
        # 2. 检查 Shell 脚本中的技术债务
        shell_files = list(target_path.rglob("*.sh"))
        for sh_file in shell_files:
            file_results = self._analyze_shell_debt(sh_file)
            results.extend(file_results)
        
        self.logger.info(f"技术债务分析完成: {len(results)} 条")
        return results
    
    def _analyze_python_debt(self, file_path: Path) -> List[Dict[str, Any]]:
        """分析 Python 文件中的技术债务"""
        results = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 技术债务 1: TODO 注释
            todo_matches = re.findall(r'#\s*TODO.*$', content, re.MULTILINE)
            if todo_matches:
                results.append({
                    "type": "technical_debt",
                    "severity": "medium",
                    "file": str(file_path),
                    "category": "todo",
                    "count": len(todo_matches),
                    "message": f"找到 {len(todo_matches)} 个 TODO 注释"
                })
            
            # 技术债务 2: FIXME 注释
            fixme_matches = re.findall(r'#\s*FIXME.*$', content, re.MULTILINE)
            if fixme_matches:
                results.append({
                    "type": "technical_debt",
                    "severity": "high",
                    "file": str(file_path),
                    "category": "fixme",
                    "count": len(fixme_matches),
                    "message": f"找到 {len(fixme_matches)} 个 FIXME 注释"
                })
            
            # 技术债务 3: 废弃代码
            deprecated_patterns = [
                r'#\s*deprecated',
                r'#\s*DEPRECATED',
                r'@deprecated',
                r'@DeprecationWarning'
            ]
            for pattern in deprecated_patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    results.append({
                        "type": "technical_debt",
                        "severity": "high",
                        "file": str(file_path),
                        "category": "deprecated",
                        "message": f"找到废弃代码: {pattern}"
                    })
                    break
            
            # 技术债务 4: 硬编码配置
            hardcoded_patterns = [
                r'localhost:\d{4}',
                r'http://127\.0\.0\.1:\d{4}',
                r'password\s*=\s*["\'].*["\']',
                r'secret\s*=\s*["\'].*["\']'
            ]
            for pattern in hardcoded_patterns:
                if re.search(pattern, content):
                    results.append({
                        "type": "technical_debt",
                        "severity": "medium",
                        "file": str(file_path),
                        "category": "hardcoded",
                        "message": f"可能包含硬编码配置: {pattern}"
                    })
                    break
            
            # 技术债务 5: 未使用的导入
            if 'import' in content:
                # 简单的未使用导入检测
                import_lines = [line for line in content.split('\n') if line.strip().startswith('import ') or line.strip().startswith('from ')]
                for import_line in import_lines:
                    module_match = re.search(r'import\s+(\w+)', import_line)
                    if module_match:
                        module_name = module_match.group(1)
                        # 检查模块是否在代码中使用
                        if module_name not in content.replace(import_line, ''):
                            results.append({
                                "type": "technical_debt",
                                "severity": "low",
                                "file": str(file_path),
                                "category": "unused_import",
                                "message": f"可能未使用的导入: {module_name}"
                            })
            
        except Exception as e:
            self.logger.warning(f"分析文件失败 {file_path}: {e}")
        
        return results
    
    def _analyze_shell_debt(self, file_path: Path) -> List[Dict[str, Any]]:
        """分析 Shell 脚本中的技术债务"""
        results = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 技术债务 1: 硬编码路径
            hardcoded_paths = ['/usr', '/opt', '/home']
            for path in hardcoded_paths:
                if path in content:
                    results.append({
                        "type": "technical_debt",
                        "severity": "medium",
                        "file": str(file_path),
                        "category": "hardcoded_path",
                        "message": f"可能包含硬编码路径: {path}"
                    })
                    break
            
            # 技术债务 2: 未引用的变量
            var_matches = re.findall(r'(\w+)=', content)
            used_vars = re.findall(r'$(\w+)', content)
            for var in var_matches:
                if var not in used_vars and var not in ['HOME', 'USER', 'PATH', 'PWD']:
                    results.append({
                        "type": "technical_debt",
                        "severity": "low",
                        "file": str(file_path),
                        "category": "unused_variable",
                        "message": f"可能未使用的变量: {var}"
                    })
            
            # 技术债务 3: 注释掉的代码
            commented_lines = [line for line in content.split('\n') if line.strip().startswith('#') and '=' in line]
            if len(commented_lines) > 5:
                results.append({
                    "type": "technical_debt",
                    "severity": "low",
                    "file": str(file_path),
                    "category": "commented_code",
                    "message": f"可能有注释掉的代码: {len(commented_lines)} 行"
                })
            
        except Exception as e:
            self.logger.warning(f"分析文件失败 {file_path}: {e}")
        
        return results
