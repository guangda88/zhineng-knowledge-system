"""
LingFlow Agent 基类
"""
import logging
import time
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pathlib import Path
import json
import sqlite3


class BaseAgent(ABC):
    """Agent 基类"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化 Agent
        
        Args:
            config: Agent 配置字典
        """
        self.config = config
        self.enabled = config.get('enabled', True)
        self.priority = config.get('priority', 1)
        self.timeout = config.get('timeout', 300)
        self.name = self.__class__.__name__
        
        # 配置日志
        self.logger = logging.getLogger(f"lingflow.agents.{self.name}")
        
        # 结果存储
        self.results: List[Dict[str, Any]] = []
        self.start_time: float = 0
        self.end_time: float = 0
    
    def is_enabled(self) -> bool:
        """检查 Agent 是否启用"""
        return self.enabled
    
    def get_priority(self) -> int:
        """获取 Agent 优先级"""
        return self.priority
    
    def execute(self, target: str) -> Dict[str, Any]:
        """
        执行 Agent 分析
        
        Args:
            target: 分析目标路径
            
        Returns:
            Dict[str, Any]: 分析结果
        """
        if not self.is_enabled():
            return {
                "agent": self.name,
                "status": "skipped",
                "reason": "Agent is disabled",
                "results": []
            }
        
        self.logger.info(f"执行 Agent: {self.name}")
        self.start_time = time.time()
        
        try:
            # 执行分析
            analysis_results = self.analyze(target)
            
            # 计算执行时间
            self.end_time = time.time()
            execution_time = self.end_time - self.start_time
            
            # 构建结果
            result = {
                "agent": self.name,
                "status": "success",
                "execution_time": execution_time,
                "results": analysis_results
            }
            
            self.logger.info(f"Agent 执行完成: {self.name} ({execution_time:.2f}s)")
            return result
            
        except Exception as e:
            self.end_time = time.time()
            execution_time = self.end_time - self.start_time
            
            self.logger.error(f"Agent 执行失败: {self.name} - {e}")
            
            result = {
                "agent": self.name,
                "status": "failed",
                "error": str(e),
                "execution_time": execution_time,
                "results": []
            }
            
            return result
    
    @abstractmethod
    def analyze(self, target: str) -> List[Dict[str, Any]]:
        """
        执行分析（子类实现）
        
        Args:
            target: 分析目标路径
            
        Returns:
            List[Dict[str, Any]]: 分析结果列表
        """
        pass
    
    def save_results(self, output_path: str) -> bool:
        """
        保存分析结果
        
        Args:
            output_path: 输出文件路径
            
        Returns:
            bool: 是否保存成功
        """
        try:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_file, 'w') as f:
                json.dump(self.results, f, indent=2)
            
            self.logger.info(f"结果已保存: {output_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"保存结果失败: {e}")
            return False
    
    def __repr__(self) -> str:
        """Agent 字符串表示"""
        return f"{self.name}(enabled={self.enabled}, priority={self.priority})"
