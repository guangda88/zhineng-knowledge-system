"""
LingFlow Agents Flow 主程序
版本: v1.0.0
"""
import sys
import logging
import json
import time
from pathlib import Path

# 添加项目根目录到 Python 路径
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# 导入 LingFlow 模块
from lingflow.agents.code_analysis import CodeAnalysisAgent
from lingflow.agents.tech_debt_cleaner import TechDebtCleanerAgent
from lingflow.workflows.workflow_controller import WorkflowController


# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('lingflow/logs/lingflow.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("lingflow")


def load_config(config_path: str = "lingflow/config/lingflow.conf") -> dict:
    """
    加载 LingFlow 配置
    
    Args:
        config_path: 配置文件路径
        
    Returns:
        dict: 配置字典
    """
    # 创建默认配置
    config = {
        'global': {
            'version': 1.0,
            'log_level': 'INFO',
            'enabled': True
        },
        'agents': {
            'code_analysis': {
                'enabled': True,
                'priority': 1,
                'timeout': 300,
                'max_workers': 4,
                'tools': ['shellcheck', 'pylint'],
                'rules': ['PEP8', 'PEP257', 'SECURITY']
            },
            'tech_debt_cleaner': {
                'enabled': True,
                'priority': 1,
                'timeout': 300,
                'auto_fix': False,
                'rules': ['TODO', 'FIXME', 'deprecated', 'hardcoded']
            },
            'security_analysis': {
                'enabled': True,
                'priority': 1,
                'timeout': 300,
                'max_workers': 4,
                'tools': ['bandit', 'safety'],
                'rules': ['OWASP', 'CWE']
            },
            'performance_analysis': {
                'enabled': True,
                'priority': 2,
                'timeout': 300,
                'max_workers': 2,
                'tools': ['cProfile', 'memory_profiler'],
                'rules': ['PERFORMANCE', 'OPTIMIZATION']
            },
            'documentation_analysis': {
                'enabled': True,
                'priority': 3,
                'timeout': 300,
                'max_workers': 2,
                'tools': ['pydocstyle', 'sphinx'],
                'rules': ['DOCUMENTATION', 'DOCSTRINGS']
            }
        },
        'project': {
            'name': 'zhineng-knowledge-system',
            'path': str(PROJECT_ROOT),
            'type': 'python',
            'version': '2.0.0'
        },
        'database': {
            'type': 'sqlite',
            'path': 'lingflow/lingflow.db',
            'backup_enabled': True,
            'backup_days': 7
        }
    }
    
    # 如果配置文件存在，则加载
    config_file_path = Path(config_path)
    if config_file_path.exists():
        try:
            import configparser
            config_parser = configparser.ConfigParser()
            config_parser.read(config_path)
            
            # 解析配置
            for section in config_parser.sections():
                if section not in config:
                    config[section] = {}
                for key, value in config_parser.items(section):
                    # 转换为适当的类型
                    if value.lower() in ['true', 'false']:
                        config[section][key] = value.lower() == 'true'
                    elif value.isdigit():
                        config[section][key] = int(value)
                    else:
                        config[section][key] = value
            
            logger.info(f"配置文件已加载: {config_path}")
        except Exception as e:
            logger.warning(f"配置文件加载失败，使用默认配置: {e}")
    else:
        logger.info(f"配置文件不存在，使用默认配置: {config_path}")
    
    return config


def main():
    """主函数"""
    logger.info("=" * 60)
    logger.info("LingFlow Agents Flow v1.0.0")
    logger.info("=" * 60)
    logger.info("")
    
    start_time = time.time()
    
    try:
        # 1. 加载配置
        config = load_config()
        logger.info("配置加载完成")
        logger.info(f"项目: {config['project']['name']}")
        logger.info(f"路径: {config['project']['path']}")
        logger.info("")
        
        # 2. 创建 Agents
        agents = []
        
        # 代码分析 Agent
        if config['agents']['code_analysis']['enabled']:
            code_analysis_agent = CodeAnalysisAgent(
                config=config['agents']['code_analysis']
            )
            agents.append(code_analysis_agent)
            logger.info(f"✅ 代码分析 Agent 已启用")
        else:
            logger.info(f"⏸️  代码分析 Agent 已禁用")
        
        # 技术债务清理 Agent
        if config['agents']['tech_debt_cleaner']['enabled']:
            tech_debt_cleaner_agent = TechDebtCleanerAgent(
                config=config['agents']['tech_debt_cleaner']
            )
            agents.append(tech_debt_cleaner_agent)
            logger.info(f"✅ 技术债务清理 Agent 已启用")
        else:
            logger.info(f"⏸️  技术债务清理 Agent 已禁用")
        
        logger.info(f"共启用 {len(agents)} 个 Agent")
        logger.info("")
        
        # 3. 创建工作流控制器
        controller = WorkflowController(config)
        logger.info("✅ 工作流控制器已创建")
        logger.info("")
        
        # 4. 执行工作流
        logger.info("开始执行工作流...")
        logger.info("")
        
        workflow_result = controller.execute_workflow(
            name="LingFlow Technical Debt Cleanup",
            agents=agents,
            workflow_type="interactive"
        )
        
        # 5. 显示结果
        logger.info("")
        logger.info("=" * 60)
        logger.info("工作流执行结果")
        logger.info("=" * 60)
        logger.info(f"工作流 ID: {workflow_result['workflow_id']}")
        logger.info(f"名称: {workflow_result['name']}")
        logger.info(f"类型: {workflow_result['type']}")
        logger.info(f"状态: {workflow_result['status']}")
        logger.info(f"执行时间: {workflow_result.get('execution_time', 0):.2f}s")
        logger.info("")
        
        if workflow_result['status'] == 'completed':
            logger.info("Agent 执行结果:")
            for i, agent_result in enumerate(workflow_result['results'], 1):
                logger.info(f"{i}. {agent_result['agent']}")
                logger.info(f"   状态: {agent_result['status']}")
                logger.info(f"   执行时间: {agent_result.get('execution_time', 0):.2f}s")
                
                if agent_result['status'] == 'success':
                    results = agent_result.get('results', [])
                    logger.info(f"   结果数: {len(results)}")
                    
                    # 按类型分组结果
                    results_by_type = {}
                    for result in results:
                        result_type = result.get('type', 'unknown')
                        if result_type not in results_by_type:
                            results_by_type[result_type] = []
                        results_by_type[result_type].append(result)
                    
                    # 显示摘要
                    for result_type, type_results in results_by_type.items():
                        logger.info(f"   {result_type}: {len(type_results)} 条")
                        # 显示前 3 条
                        for r in type_results[:3]:
                            logger.info(f"     - {r.get('message', 'N/A')}")
                
                logger.info("")
        
        # 6. 保存报告
        report_path = Path("lingflow/reports/on_demand/workflow_report.json")
        report_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(report_path, 'w') as f:
            json.dump(workflow_result, f, indent=2, ensure_ascii=False)
        
        logger.info(f"✅ 报告已保存: {report_path}")
        logger.info("")
        
        end_time = time.time()
        total_time = end_time - start_time
        
        logger.info("=" * 60)
        logger.info(f"总执行时间: {total_time:.2f}s")
        logger.info("=" * 60)
        
        return 0
        
    except Exception as e:
        logger.error(f"执行失败: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
